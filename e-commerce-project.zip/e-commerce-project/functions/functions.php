<?php
$con=mysqli_connect('localhost','root','','ibbu_e');

function getip(){
	$ip=$_SERVER['REMOTE_ADDR'];
	if(!empty($_SERVER['HTTP_CLIENT_IP'])){
		$ip=$_SERVER['HTTP_CLIENT_IP'];
	}
		elseif(!empty($_SERVER['HTTP_X_FORWORDED_FOR'])){
		$ip=$_SERVER['HTTP_X_FORWORDED_FOR'];
	}
	return $ip ;
}


function cart(){
	if(isset($_GET['add_cart'])){
        global $con;
		$ip=getip();
		$pro_id=$_GET['add_cart'];
        $check_pro="select * from cart where ip_add='$ip' AND p_id='$pro_id' ";
        $check_run=mysqli_query($con,$check_pro);
        if(mysqli_num_rows($check_run)>0){
        	echo "<script>alert('product already added to cart')</script>";
        }
        else{
          $insert_pro="insert into cart (p_id,ip_add) values ('$pro_id','$ip')";
        	$insert_run=mysqli_query($con, $insert_pro);
        	if($insert_run){
        	echo "<script>alert(' added to cart')</script>";
        	echo "<script>window.open('index.php','_self')</script>";
        }
        }
	}

}

function total_items(){
	global $con;
	
	if(isset($_GET['add_cart'])){
		$ip=getip();

		$get_items="select * from cart where ip_add='$ip'";
		$run_items=mysqli_query($con,$get_items);
		$count_items=mysqli_num_rows($run_items);
	}
	else{
		$ip=getip();

		$get_items="select * from cart where ip_add='$ip'";
		$run_items=mysqli_query($con,$get_items);
		$count_items=mysqli_num_rows($run_items);
	}
	echo $count_items-2;
}


function total_price(){
	global $con;
	$total=0;
	$ip=getip();
	$select_price="select * from cart where ip_add='$ip'";
	$run_price=mysqli_query($con,$select_price);
	while ($p_price=mysqli_fetch_array($run_price)) {
		$pro_id=$p_price['p_id'];
		$cal_price="select * from products where product_id=$pro_id";
		$run_cal=mysqli_query($con,$cal_price);
		while($pp_price=mysqli_fetch_array($run_cal)){
			$product_price=array($pp_price['product_price']);
			$value=array_sum($product_price);
			$total += $value;
		}
		
	}
	echo $total;

}


function getcat(){
	global $con;
	$get_cat="select * from categories";
	$run_cat=mysqli_query($con,$get_cat);
	while ($row_cat=mysqli_fetch_array($run_cat)) {
		$cat_id=$row_cat['cat_id'];
		$cat_title=$row_cat['cat_title'];

		echo "<li><a href='index.php?cat=$cat_id'>$cat_title</a></li>";
	}
}


function getbrand(){
	global $con;
	$get_brand="select * from brands";
	$run_brand=mysqli_query($con,$get_brand);
	while ($row_brand=mysqli_fetch_array($run_brand)) {
		$brand_id=$row_brand['brand_id'];
		$brand_title=$row_brand['brand_title'];

		echo "<li><a href='index.php?brand=$brand_id'>$brand_title</a></li>";
	}
}


function getpro(){
	if(!isset($_GET['cat'])){
		if(!isset($_GET['brand'])){
	global $con;
	$get_pro="select * from products order by rand() LIMIT 0,6";
	$run_pro=mysqli_query($con,$get_pro);
	while ($row_pro=mysqli_fetch_array($run_pro)) {
		$pro_id=$row_pro['product_id'];
		$pro_title=$row_pro['product_title'];
		$pro_keywords=$row_pro['product_keywords'];
		$pro_price=$row_pro['product_price'];
		$pro_image=$row_pro['product_image'];
		$pro_desc=$row_pro['product_desc'];
		
		echo "
		<div id='single_pro'>
		     <h3>$pro_title</h3>
		      <a href='details.php?pro_id=$pro_id'><img id='pro' src='admin/product_images/$pro_image' alt='image' width='180' height='180'></a>
		     <p><b>price: $ $pro_price</b></p>
		     <a href='details.php?pro_id=$pro_id' style=' float:left;' >details</a>
		     <a href='index.php?add_cart=$pro_id'><button style=' float:right;' >Add to cart</button></a>
		</div>



		";
	}
}
}
}




function getcatpro(){
	if(isset($_GET['cat'])){
		$product_cat=$_GET['cat'];
	global $con;
	$get_catpro="select * from products where product_cat='$product_cat'";
	$run_catpro=mysqli_query($con,$get_catpro);
	$count_cat=mysqli_num_rows($run_catpro);
	if($count_cat==0){
		echo "<h2>There are no products in this category</h2>";
	}
	while ($row_catpro=mysqli_fetch_array($run_catpro)) {
		$pro_id=$row_catpro['product_id'];
		$pro_title=$row_catpro['product_title'];
		$pro_keywords=$row_catpro['product_keywords'];
		$pro_price=$row_catpro['product_price'];
		$pro_image=$row_catpro['product_image'];
		$pro_desc=$row_catpro['product_desc'];
		
		echo "
		<div id='single_pro'>
		     <h3>$pro_title</h3>
		     <a href='details.php?pro_id=$pro_id'><img id='pro' src='admin/product_images/$pro_image' alt='image' width='180' height='180'></a>
		     <p><b>$ $pro_price</b></p>
		     <a href='details.php?pro_id=$pro_id' style=' float:left;' >details</a>
		     <a href='index.php?pro_id=$pro_id'><button style=' float:right;' >Add to cart</button></a>
		</div>



		";
	}
}
}

function getbrandpro(){
	if(isset($_GET['brand'])){
		$product_brand=$_GET['brand'];
	global $con;
	$get_brandpro="select * from products where product_brand='$product_brand'";
	$run_brandpro=mysqli_query($con,$get_brandpro);
	$count_brand=mysqli_num_rows($run_brandpro);
	if($count_brand==0){
		echo "<h2>There are no products in this brand</h2>";
	}
	while ($row_brandpro=mysqli_fetch_array($run_brandpro)) {
		$pro_id=$row_brandpro['product_id'];
		$pro_title=$row_brandpro['product_title'];
		$pro_keywords=$row_brandpro['product_keywords'];
		$pro_price=$row_brandpro['product_price'];
		$pro_image=$row_brandpro['product_image'];
		$pro_desc=$row_brandpro['product_desc'];
		
		echo "
		<div id='single_pro'>
		     <h3>$pro_title</h3>
		     <a href='details.php?pro_id=$pro_id'><img id='pro' src='admin/product_images/$pro_image' alt='image' width='180' height='180'></a>
		     <p><b>$ $pro_price</b></p>
		     <a href='details.php?pro_id=$pro_id' style=' float:left;' >details</a>
		     <a href='index.php?pro_id=$pro_id'><button style=' float:right;' >Add to cart</button></a>
		</div>



		";
	}
}
}

?>