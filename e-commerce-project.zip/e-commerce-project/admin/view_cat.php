<?php

if(!isset($_SESSION['user_name'])){
	header('location:login.php');
}
else{
?>

<div id="Welcome">
<table width="750" border="5" bgcolor="wheat" >
	<tr >
		<td align="center" colspan="10" bgcolor="orange">View all categories</td>
	</tr>
	<tr bgcolor="wheat" >
		<td>category id</td>
		<td>category title</td>
		<td>delete </td>
		<td>edit </td>
		
		
	</tr>
	<tr>
	<?php
include('includes/connect.php');
$query_cat="select * from categories order by  1 DESC ";
$run_cat=mysqli_query($con,$query_cat);
$i=0;
while ($row=mysqli_fetch_assoc($run_cat)) {
	 $cat_id=$row['cat_id'];
	 $cat_title=$row['cat_title'];
	 $i++;
     ?>
		<td><?php echo $i; ?></td>
		<td><?php echo $cat_title; ?></td>
		
		<td><a href="delete_cat.php?del_cat=<?php echo $cat_id;?>"><center><img src="images/delete.jpg" width="30" height="30"></center></a></td>
		<td><a href="index.php?edit_cat=<?php echo $cat_id;?>"><center><img src="images/edit.jpg" width="30" height="30"></center></a></td>
	</tr>
	<?php } ?>
</table>
</div>

</body>
<?php } ?>