<?php
session_start();
if(!isset($_SESSION['user_name'])){
	header('location:login.php');
}
else{
?>

<html>
<head>
<title>Admin panel</title>
<link rel="stylesheet" href="admin_style.css" media="all">
</head>
<body>
<div id="header">
<center>

	<a href="index.php"><h1 id="headtitle">
<img src="images/admin.png" width="120" height="100" id="admin" alt="Admin">Welcome to the Admin Panel</h1></a></center>
</div>
<div id="sidebar">.
<center>
	<h2><a href="index.php?insert_product">Insert new product</a></h2>
	<h2><a href="index.php?view_product">View all products</a></h2>
	<h2><a href="index.php?insert_category">Insert new category</a></h2>
	<h2><a href="index.php?view category">View all categories</a></h2>
	<h2><a href="index.php?insert_brand">Insert new brands</a></h2>
	<h2><a href="index.php?view_brand">View all brands</a></h2>
	<h2><a href="index.php?view_customer">View customers</a></h2>
	<h2><a href="index.php?view_orders">View orders</a></h2>
	<h2><a href="index.php?view_payments">View payments</a></h2>
	<h2><a href="logout.php">Admin Logout</a></h2>
</center>
		
</div>
<div id="Welcome">
<center>
<?php
if(!isset($_GET['insert_product'])){
	if(!isset($_GET['view_product'])){
		if(!isset($_GET['insert_category'])){
			if(!isset($_GET['view_category'])){
				if(!isset($_GET['insert_brand'])){
					if(!isset($_GET['view_brand'])){
						if(!isset($_GET['view_customer'])){
							if(!isset($_GET['view_product'])){
								if(!isset($_GET['view_orders'])){
									if(!isset($_GET['view_payments'])){
										if(!isset($_GET['edit_cat'])){
											if(!isset($_GET['edit_brand'])){
echo "<h1>Welcome to your Admin Panel</h1>
	<p>This is the admin panel for the personal website.The page contains the information of the website.</p>
	</center>";
}
}
}
}
}
}
}
}
}
}
}
}
	?>
	<?php
     if(isset($_GET['insert_product'])){
     	include("insert_product.php");
     }
      if(isset($_GET['view_product'])){
     	include("view_products.php");
     }
     if(isset($_GET['insert_category'])){
     	include("insert_cat.php");
     }
     if(isset($_GET['view_category'])){
     	include("view_cat.php");
     }
     if(isset($_GET['edit_cat'])){
     	include("edit_cat.php");
     }
     if(isset($_GET['insert_brand'])){
     	include("insert_brand.php");
     }
     if(isset($_GET['view_brand'])){
     	include("view_brand.php");
     }
     if(isset($_GET['edit_brand'])){
     	include("edit_brand.php");
     }
     if(isset($_GET['view_customer'])){
     	include("view_customer.php");
     }
	?>
	</center>
</div>

</body>
</html>
<?php } ?>