<?php
include("includes/connect.php");
if(isset($_GET['edit_cat'])){

	$cat_id=$_GET['edit_cat'];
	$get_cat="select * from categories where cat_id='$cat_id'";
	$run_cat=mysqli_query($con,$get_cat);
	$row_cat=mysqli_fetch_array($run_cat);
	$cat_id=$row_cat['cat_id'];
	$cat_title=$row_cat['cat_title'];
}
?>

<form action="" method="post">

<table  width="600" align="center" border="10">
<tr>
<td id="id" align="center" bgcolor="darkgoldenrod" colspan="6"><h1><b><i>update category</i></b></h1></td>
</tr>
<td align="right">New category name:</td>
<td><input type="text" name="name" value="<?php echo $cat_title; ?>"></td>
</tr>
<tr>
<td align="center" colspan="6"><input type="submit" name="add_cat" value="update now"></td>
</tr>
</form>
<?php
include("includes/connect.php");
if(isset($_POST['add_cat'])){
	$update_id=$cat_id;
	$new_cat=$_POST['name'];
	$update_cat="update categories set cat_title='$new_cat' where cat_id='$update_id'";
	$run_update=mysqli_query($con,$update_cat);
	if($run_update){
		echo "<script>alert('Category has been updated')</script>";
		echo "<script>window.open('index.php?view_category','_self')</script>";
	}
	else{
		echo "<script>alert('error in updating category......please try again ')</script>";
		echo "<script>window.open('index.php?view_category','_self')</script>";
	}
}
?>