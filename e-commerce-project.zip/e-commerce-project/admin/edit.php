<?php
session_start();

if(!isset($_SESSION['user_name'])){
	header('location:login.php');
}
else{
?>
<html>
<head>
<title>Admin panel</title>
<link rel="stylesheet" href="admin_style.css" media="all">
</head>
<body>
<div id="header">
<center>

	<a href="index.php"><h1 id="headtitle">
<img src="images/admin.png" width="120" height="100" id="admin">Welcome to the Admin Panel</h1></a></center>
</div>
<div id="sidebar">.
<center>
	<h2><a href="index.php?insert_product">Insert new product</a></h2>
	<h2><a href="index.php?view_product">View all products</a></h2>
	<h2><a href="index.php?insert_category">Insert new category</a></h2>
	<h2><a href="index.php?view category">View all categories</a></h2>
	<h2><a href="index.php?insert_brand">Insert new brands</a></h2>
	<h2><a href="index.php?view_brand">View all brands</a></h2>
	<h2><a href="index.php?view_customer">View customers</a></h2>
	<h2><a href="index.php?view_orders">View orders</a></h2>
	<h2><a href="index.php?view_payments">View payments</a></h2>
	<h2><a href="logout.php">Admin Logout</a></h2>
</center>
		
</div>
<?php 
include("includes/connect.php");
if (isset($_GET['edit'])){
	$edit_id=$_GET['edit'];
	$query="select * from products where product_id='$edit_id'";
	$run=mysqli_query($con,$query);
	while ($row=mysqli_fetch_assoc($run)) {
	 $product_id=$row['product_id'];
	 $product_category=$row['product_cat'];
	 $product_title=$row['product_title'];
	 $product_brand=$row['product_brand'];
	 $product_keywords=$row['product_keywords'];
     $product_price=$row['product_price'];
     $product_image=$row['product_image'];
     $product_desc=$row['product_desc'];
 }
}
     ?>
 

<style>
td {color:black; font-family: comic sans MS; background: wheat;}
#id {background: darkgoldenrod;}
</style>
<form method="post" action="edit.php?edit_form=<?php echo $product_id;?>"  enctype="multipart/form-data">
<table  width="800" align="center" border="10">
<tr>
<td id="id" align="center" bgcolor="darkgoldenrod" colspan="6"><h1><b><i>Update your Product</i></b></h1></td>
</tr>
<td>product title:</td>
<td><input type="text" name="title" value="<?php echo $product_title;?>" ></td>
</tr>
<tr>
<td>product category:</td>
<td>
	<select name="category">
		<option><?php echo $product_category; ?></option>
		<?php

		$get_cat="select * from categories";
	$run_cat=mysqli_query($con,$get_cat);
	while ($row_cat=mysqli_fetch_array($run_cat)) {
		$cat_id=$row_cat['cat_id'];
		$cat_title=$row_cat['cat_title'];

		echo "<option value='$cat_id'>$cat_title</option>";
	} 

		?>
	</select>
</td>
</tr>
<tr>
<td>product brand:</td>
<td>
	<select name="brand">
		<option><?php echo $product_brand; ?></option>
		<?php
$get_brand="select * from brands";
	$run_brand=mysqli_query($con,$get_brand);
	while ($row_brand=mysqli_fetch_array($run_brand)) {
		$brand_id=$row_brand['brand_id'];
		$brand_title=$row_brand['brand_title'];
echo "<option value='$brand_id'>$brand_title</option>";
	} 

		?>
</td>
</tr>
<tr>
<td>product keywords:</td>
<td><input type="text" name="keywords" value="<?php echo $product_keywords; ?>"></td>
</tr>

<tr>
<td>product price:</td>
<td><input type="number" name="price" value="<?php echo $product_price; ?>"></td>
</tr>
<tr>
<td>product image:</td>
<td><input type="file" name="image"><img src="product_images/<?php echo $product_image; ?>" width="150" height="150"></td>
</tr>
<tr>
<td>product desc:</td>
<td><textarea name="text" cols="40" rows="20"><?php  echo $product_desc;?></textarea></td>
</tr>
<tr>
<td align="center" colspan="6"><input type="submit" name="submit" value="update product now"></td>
</tr>
</table>
</form>
<?php
include("includes/connect.php");
global $con;
if(isset($_POST['submit'])){
	$update_id=$_GET['edit_form'];

	 $product_title1=$_POST['title'];
	 $product_category1=$_POST['category'];
	 $product_brand1=$_POST['brand'];
	 $product_keywords1=$_POST['keywords'];
	 $product_price1=$_POST['price'];
	 $product_image1=$_FILES['image']['name'];
	 $image_tmp1=$_FILES['image']['tmp_name'];
	 $product_desc1=$_POST['text'];
	 if(empty($product_title1)||empty($product_category1)||empty($product_brand1)||empty($product_keywords1)||empty($product_price1)||empty($product_image1)||empty($product_desc1)){
		echo "<script>alert('some field is empty please enter')</script>";
		echo "<script>window.open('edit.php','edit.php?edit_form=<?php echo $update_id; ?>')</script>";
		die(); 
	}
	else{
		move_uploaded_file($image_tmp1, "product_images/$product_image1");
	    $query_update="update products set product_title='$product_title1',product_cat='$product_category1',product_brand='$product_brand1',product_keywords='$product_keywords1',product_price='$product_price1',product_image='$product_image1',product_desc='$product_desc1' where product_id='$update_id'";
	    $update_run=mysqli_query($con,$query_update);
		if( $update_run){
			echo '<center><h1 >product has been updated successfully</h1></center>';
			echo "<script>alert('your product has been updated successfully')</script>";
			echo "<script>window.open('index.php?view_products','_self')</script>";
		}
		else{
			echo "<script>alert(' error in updating..$update_id.please try again')</script>";
			echo "<script>window.open('index.php?view_products','_self')</script>";
		}

	}


}
}
?>
