<?php

if(!isset($_SESSION['user_name'])){
	header('location:login.php');
}
else{
?>

<div id="Welcome">
<table width="1250" border="5" bgcolor="silver" >
	<tr >
		<td align="center" colspan="10" bgcolor="orange">View all customers</td>
	</tr>
	<tr bgcolor="wheat">
		<td>customer id</td>
		<td>customer name</td>
		<td>customer email</td>
		<td>customer image</td>
		<td>delete </td>
		
		
		
	</tr>
	<tr>
	<?php
include('includes/connect.php');
$query="select * from customers order by  1 DESC ";
$run=mysqli_query($con,$query);
$i=0;
while ($row=mysqli_fetch_assoc($run)) {
	 $c_id=$row['customer_id'];
	 $c_name=$row['customer_name'];
	 $c_email=$row['customer_email'];
	 $c_image=$row['customer_image'];
	 $i++;
     ?>
		<td><?php echo $i; ?></td>
		<td><?php echo $c_name; ?></td>
		<td><?php echo $c_email ; ?></td>
		<td><img  src="../customers/customer images/<?php echo $c_image; ?>" width="120" height="80" style="align-items: center;"</td>
		
		<td><a href="delete_c.php?del_c=<?php echo $c_id;?>"><center><img src="images/delete.jpg" width="30" height="30"></center></a></td>
		
	</tr>
	<?php } ?>
</table>
</div>

</body>
<?php } ?>