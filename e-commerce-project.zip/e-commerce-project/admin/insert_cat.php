<form action="" method="post">

<table  width="600" align="center" border="10">
<tr>
<td id="id" align="center" bgcolor="darkgoldenrod" colspan="6"><h1><b><i>Add new category</i></b></h1></td>
</tr>
<td align="right">New category name:</td>
<td><input type="text" name="name" required></td>
</tr>
<tr>
<td align="center" colspan="6"><input type="submit" name="add_cat" value="Add now"></td>
</tr>
</form>
<?php
include("includes/connect.php");
if(isset($_POST['add_cat'])){
	$new_cat=$_POST['name'];
	$insert_cat="insert into categories (cat_title) values('$new_cat')";
	$run_insert=mysqli_query($con,$insert_cat);
	if($run_insert){
		echo "<script>alert('New category has been added')</script>";
		echo "<script>window.open('index.php?view_category','_self')</script>";
	}
	else{
		echo "<script>alert('error in adding new category......please try again ')</script>";
		echo "<script>window.open('index.php?view_category','_self')</script>";
	}
}
?>