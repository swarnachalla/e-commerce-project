<?php

if(!isset($_SESSION['user_name'])){
	header('location:login.php');
}
else{
?>

<div id="Welcome">
<table width="1250" border="5" bgcolor="silver" >
	<tr >
		<td align="center" colspan="10" bgcolor="orange">View all posts</td>
	</tr>
	<tr bgcolor="wheat">
		<td>product no</td>
		<td>product title</td>
		<td>product price</td>
		<td>product image</td>
		<td>delete product</td>
		<td>edit product</td>
		
		
	</tr>
	<tr>
	<?php
include('includes/connect.php');
$query="select * from products order by  1 DESC ";
$run=mysqli_query($con,$query);
$i=0;
while ($row=mysqli_fetch_assoc($run)) {
	 $pro_id=$row['product_id'];
	 $pro_title=$row['product_title'];
	 $pro_price=$row['product_price'];
	 $pro_image=$row['product_image'];
	 $i++;
     ?>
		<td><?php echo $i; ?></td>
		<td><?php echo $pro_title; ?></td>
		<td><?php echo $pro_price ; ?></td>
		<td><img  src="product_images/<?php echo $pro_image; ?>" width="120" height="80" style="align-items: center;"</td>
		
		<td><a href="delete.php?del=<?php echo $pro_id;?>"><center><img src="images/delete.jpg" width="30" height="30"></center></a></td>
		<td><a href="edit.php?edit=<?php echo $pro_id;?>"><center><img src="images/edit.jpg" width="30" height="30"></center></a></td>
	</tr>
	<?php } ?>
</table>
</div>

</body>
<?php } ?>