<?php

if(!isset($_SESSION['user_name'])){
	header('location:login.php');
}
else{
?>

<div id="Welcome">
<table width="750" border="5" bgcolor="wheat" >
	<tr >
		<td align="center" colspan="10" bgcolor="orange">View all brands</td>
	</tr>
	<tr bgcolor="wheat" >
		<td>brand id</td>
		<td>brand title</td>
		<td>delete </td>
		<td>edit </td>
		
		
	</tr>
	<tr>
	<?php
include('includes/connect.php');
$query_brand="select * from brands order by  1 DESC ";
$run_brand=mysqli_query($con,$query_brand);
$i=0;
while ($row=mysqli_fetch_assoc($run_brand)) {
	 $brand_id=$row['brand_id'];
	 $brand_title=$row['brand_title'];
	 $i++;
     ?>
		<td><?php echo $i; ?></td>
		<td><?php echo $brand_title; ?></td>
		
		<td><a href="delete_brand.php?del_brand=<?php echo $brand_id;?>"><center><img src="images/delete.jpg" width="30" height="30"></center></a></td>
		<td><a href="index.php?edit_brand=<?php echo $brand_id;?>"><center><img src="images/edit.jpg" width="30" height="30"></center></a></td>
	</tr>
	<?php } ?>
</table>
</div>

</body>
<?php } ?>