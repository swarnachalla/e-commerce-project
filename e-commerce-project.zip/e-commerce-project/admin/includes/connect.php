<?php
$con=mysqli_connect('localhost','root','','ibbu_e');
?>