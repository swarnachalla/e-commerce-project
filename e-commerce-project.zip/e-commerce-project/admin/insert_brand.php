<form action="" method="post">

<table  width="600" align="center" border="10">
<tr>
<td id="id" align="center" bgcolor="darkgoldenrod" colspan="6"><h1><b><i>Add new brand</i></b></h1></td>
</tr>
<td align="right">New brand name:</td>
<td><input type="text" name="name" required></td>
</tr>
<tr>
<td align="center" colspan="6"><input type="submit" name="add_brand" value="Add now"></td>
</tr>
</form>
<?php
include("includes/connect.php");
if(isset($_POST['add_brand'])){
	$new_brand=$_POST['name'];
	$insert_brand="insert into brands (brand_title) values('$new_brand')";
	$run_insert=mysqli_query($con,$insert_brand);
	if($run_insert){
		echo "<script>alert('New brand has been added')</script>";
		echo "<script>window.open('index.php?view_brand','_self')</script>";
	}
	else{
		echo "<script>alert('error in adding new brand......please try again ')</script>";
		echo "<script>window.open('index.php?view_brand','_self')</script>";
	}
}
?>