<?php
session_start();
$use=$_SESSION['user_name'];
if(!isset($_SESSION['user_name'])){
	header('location:login.php');
}
else{
include('includes/connect.php');
if(isset($_GET['del'])){
	$del_id=$_GET['del'];
	$del_query="delete from products where product_id=$del_id";
	if(mysqli_query($con,$del_query)){
		echo "<script>alert('product has been deleted ')</script>";
		echo "<script>window.open('index.php?view_products','_self')</script>";
	}
}
}