<?php
include("includes/connect.php");
if(isset($_GET['edit_brand'])){

	$brand_id=$_GET['edit_brand'];
	$get_brand="select * from brands where brand_id='$brand_id'";
	$run_brand=mysqli_query($con,$get_brand);
	$row_brand=mysqli_fetch_array($run_brand);
	$brand_id=$row_brand['brand_id'];
	$brand_title=$row_brand['brand_title'];
}
?>

<form action="" method="post">

<table  width="600" align="center" border="10">
<tr>
<td id="id" align="center" bgcolor="darkgoldenrod" colspan="6"><h1><b><i>update  brand</i></b></h1></td>
</tr>
<td align="right">New brand name:</td>
<td><input type="text" name="name" value="<?php echo $brand_title; ?>"></td>
</tr>
<tr>
<td align="center" colspan="6"><input type="submit" name="add_brand" value="update now"></td>
</tr>
</form>
<?php
include("includes/connect.php");
if(isset($_POST['add_brand'])){
	$update_id=$brand_id;
	$new_brand=$_POST['name'];
	$update_brand="update brands set brand_title='$new_brand' where brand_id='$update_id'";
	$run_update=mysqli_query($con,$update_brand);
	if($run_update){
		echo "<script>alert('Brand has been updated')</script>";
		echo "<script>window.open('index.php?view_brand','_self')</script>";
	}
	else{
		echo "<script>alert('error in updating brand......please try again ')</script>";
		echo "<script>window.open('index.php?view_brand','_self')</script>";
	}
}
?>