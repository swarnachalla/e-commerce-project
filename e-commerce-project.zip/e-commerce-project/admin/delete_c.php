<?php
session_start();
$use=$_SESSION['user_name'];
if(!isset($_SESSION['user_name'])){
	header('location:login.php');
}
else{
include('includes/connect.php');
if(isset($_GET['del_c'])){
	$del_id=$_GET['del_c'];
	$del_c="delete from customers where customer_id=$del_id";
	if(mysqli_query($con,$del_c)){
		echo "<script>alert('customer has been deleted ')</script>";
		echo "<script>window.open('index.php?view_customer','_self')</script>";
	}
	else{
			echo "<script>alert(' error in deleting..$del_id.please try again')</script>";
			echo "<script>window.open('index.php?view_customer','_self')</script>";
		}
}
}