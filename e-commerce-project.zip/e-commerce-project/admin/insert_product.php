<?php
include("includes/connect.php");
?>
<style>
td {color:black; font-family: comic sans MS; background: wheat;}
#id {background: darkgoldenrod;}
</style>
<form method="post" action="insert_product.php" enctype="multipart/form-data">
<table  width="800" align="center" border="10">
<tr>
<td id="id" align="center" bgcolor="darkgoldenrod" colspan="6"><h1><b><i>Insert New Product</i></b></h1></td>
</tr>
<tr>
<td>product title:</td>
<td><input type="text" name="title" required ></td>
</tr>
<tr>
<td>product category:</td>
<td>
	<select name="category">
		<option>select a category</option>
		<?php

		$get_cat="select * from categories";
	$run_cat=mysqli_query($con,$get_cat);
	while ($row_cat=mysqli_fetch_array($run_cat)) {
		$cat_id=$row_cat['cat_id'];
		$cat_title=$row_cat['cat_title'];

		echo "<option value='$cat_id'>$cat_title</option>";
	} 

		?>
	</select>
</td>
</tr>
<tr>
<td>product brand:</td>
<td>
	<select name="brand">
		<option>select a brand</option>
		<?php
$get_brand="select * from brands";
	$run_brand=mysqli_query($con,$get_brand);
	while ($row_brand=mysqli_fetch_array($run_brand)) {
		$brand_id=$row_brand['brand_id'];
		$brand_title=$row_brand['brand_title'];
echo "<option value='$brand_id'>$brand_title</option>";
	} 

		?>
</td>
</tr>
<tr>
<td>product keywords:</td>
<td><input type="text" name="keywords"></td>
</tr>

<tr>
<td>product price:</td>
<td><input type="number" name="price"></td>
</tr>
<tr>
<td>product image:</td>
<td><input type="file" name="image"></td>
</tr>
<tr>
<td>product desc:</td>
<td><textarea name="text" cols="40" rows="20"></textarea></td>
</tr>
<tr>
<td align="center" colspan="6"><input type="submit" name="submit" value="insert product now"></td>
</tr>
</table>
</form>
<?php
include("includes/connect.php");
global $con ;

if(isset($_POST['submit'])){
	 $product_title=$_POST['title'];
	 $product_category=$_POST['category'];
	 $product_brand=$_POST['brand'];
	 $product_keywords=$_POST['keywords'];
	 $product_price=$_POST['price'];
	 $product_desc=$_POST['text'];
	 $product_image=$_FILES['image']['name'];
	 $image_tmp=$_FILES['image']['tmp_name'];
	 if(empty($product_title)||empty($product_category)||empty($product_price)||empty($product_brand)||empty($product_keywords)||empty($product_desc)||empty($product_image)){
		echo "<script>alert('some field is empty please enter')</script>";
		exit(); 
	}
	else{
		move_uploaded_file($image_tmp, "product_images/$product_image");
	     $query="insert into products(product_cat,product_brand,product_title,product_price,product_desc,product_image,product_keywords) values('$product_category','$product_brand','$product_title','$product_price','$product_desc','$product_image','$product_keywords')";
	     $run=mysqli_query($con,$query);
		if($run){
			echo '<center><h1 >product has been inserted successfully</h1></center>';
			echo "<script>alert('product inserted successfully')</script>";
			echo "<script>window.open('index.php?insert_product','_self')</script>";
		}
		else
		{
			echo "<script>alert('error in inserting the product')</script>";
		}

	}


}
