<?php 
session_start();
include('functions/functions.php');

?>
<html>
<head>
<title>EKart</title>
<link rel="stylesheet" href="styles/styles.css" media="all">
</head>
<body>
<!--body wrapper starts here-->
<div class="body_wrapper">
<!--header starts here-->
<div id="header">
	<img id="logo" src="images/admin.png" alt="admin image" height="150" width="200">
	<b>Welcome to EKart</b>
	<img id="banner" src="images/banner.jpg" alt="banner image" height="150" width="500">
</div>
<!--header ends here-->
<!--navbar starts here-->
<div id="navbar">
	<ul id="nav">
	<li><a href="index.php">Home</a></li>
	<li><a href="all_products.php">All Products</a></li>
	<li><a href="customers/my_account.php">My Account</a></li>
	<li><a href="register.php">Sign Up</a></li>
	<li><a href="cart.php">Shopping Cart</a></li>
	<li><a href="contact.php">Contact Us</a></li>
	</ul>
	<!--form starts here-->
<div id="form">
<form  action="results.php" method="get" enctype="multipart/form-data">
<input type="text" name="searchtext" placeholder="search Products here" >
<input type="submit" name="search" value="search">
	
</form>
</div>
<!--form ends here-->
</div>
<!--navbar ends here-->
<!--content wrapper starts here-->
<div class="content_wrapper">
<!--sidebar starts here-->
<div id="sidebar">
	<div id="side_title">Categories</div>
	
	   <ul id="cats">
	   
	   <?php  echo getcat(); ?>
	   </ul>


	<div id="side_title">Brands</div>
	
	   <ul id="cats">

	   <?php  echo getbrand(); ?>

	   </ul>   
	
	
</div>
<!--sidebar ends here-->
<!--content  starts here-->
<div id="content">
<h2>Contact Us</h2>
<form action="contact.php" method="post" onsubmit="return ValidateForm(this);" target="_top">
<input name="skip_WhereToSend" type="hidden" value="pathanmohammedibrahimkhan@gmail.com" />
<input name="skip_SnapHostID" type="hidden" value="AWA7Q4CPNT5H" />
<input name="skip_WhereToReturn" type="hidden" value="http://ibrahimkhan.me" />
<input name="skip_Subject" type="hidden" value="Contact Us Form" />
<input name="skip_ShowUsersIp" type="hidden" value="1" />
<input name="skip_SendCopyToUser" type="hidden" value="1" />
<script type="text/javascript">
function ValidateForm(frm) {
if (frm.Name.value == "") {alert('Name is required.');frm.Name.focus();return false;}
if (frm.FromEmailAddress.value == "") {alert('Email address is required.');frm.FromEmailAddress.focus();return false;}
if (frm.FromEmailAddress.value.indexOf("@") < 1 || frm.FromEmailAddress.value.indexOf(".") < 1) {alert('Please enter a valid email address.');frm.FromEmailAddress.focus();return false;}
if (frm.Comments.value == "") {alert('Please enter comments or questions.');frm.Comments.focus();return false;}

return true; }

</script>
<table border="0" cellpadding="5" cellspacing="0" width="600">
<tr>
<td><b>Name*:</b></td>
<td><input name="Name" type="text" maxlength="60" style="width:350px;" /></td>
</tr><tr>
<td><b>Phone number:</b></td>
<td><input name="PhoneNumber" type="text" maxlength="43" style="width:350px;" /></td>
</tr><tr>
<td><b>Email address*:</b></td>
<td><input name="FromEmailAddress" type="text" maxlength="60" style="width:350px;" /></td>
</tr><tr>
<td><b>Comments and questions*:</b></td>
<td><textarea name="Comments" rows="7" cols="40" style="width:350px;"></textarea></td>
</tr>
</table> <br />
* - required fields. &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
<input name="skip_Submit" type="submit" value="Submit" />
</td></tr>
</table><br />
</form>
</div>
<!--content ends here-->

</div>
<!--content wrapper ends here-->

<div id="footer" align="center">
	<h1>&copy; 2017 by www.ifirst.com</h1>
</div>
</div>
<!--body wrapper endss here-->
</body>
</html>