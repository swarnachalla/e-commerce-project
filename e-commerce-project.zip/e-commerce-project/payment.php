<div >
<h1 align="center" style="color: darkgoldenrod;">pay through paypal</h1>
<h2 align="center" style="color: orange;">secure payment</h2>
	<form action="https://www.paypal.com/cgi-bin/webscr" method="post">

  <!-- Identify your business so that you can collect the payments. -->
  <input type="hidden" name="business" value="swarnabharathi1497@gmai">

  <!-- Specify a Buy Now button. -->
  <input type="hidden" name="cmd" value="_xclick">

  <!-- Specify details about the item that buyers will purchase. -->
  <input type="hidden" name="item_name" value="Hot Sauce-12oz. Bottle">
  <input type="hidden" name="amount" value="5.95">
  <input type="hidden" name="currency_code" value="USD">

  <!-- Display the payment button. -->
  <input type="image" name="submit" border="0"
  src="images/payment.jpg"
  alt="Buy Now">
 

</form>

</div>