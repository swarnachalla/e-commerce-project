<?php 

include('includes/connect.php');

?>
<div>
	
	<form method="post" action="">
		<table width="500" align="center" bgcolor="wheat" border="5">
		<tr align="center" bgcolor="darkgoldenrod">
			<td colspan="4">Login or register</td>
		</tr>
		<tr>
			<td>login:</td>
			<td><input type="text" name="email" placeholder="email" required></td>
		</tr>
		<tr>
			<td>password:</td>
			<td><input type="password" name="password" placeholder="password" required></td>
		</tr>
		<tr align="right">
			<td colspan="4"><a href="checkout.php?forgot_pass">forgot password</a></td>
		</tr>
		<tr align="center">
			
			<td colspan="4"><input type="submit" name="login" value="login"></td>
		</tr>
		</table>
		<a href="register.php" style="float: right; text-decoration: none; padding-right: 30px; ">New? register here</a>
	</form>
	<?php 
	if(isset($_POST['login'])){
		$ip=getip();
		$c_email=$_POST['email'];
		$c_pass=$_POST['password'];
		$sel_c="select * from customers where customer_email='$c_email' AND customer_password='$c_pass'";
		$run_c=mysqli_query($con,$sel_c);
		$check_customer=mysqli_num_rows($run_c);
		if($check_customer==0){
			echo "<script>alert('username or password is incorrect, please try again')</script>";
			exit();
		}
		$sel_cart="select * from cart where ip_add='$ip'";
		$sel_run=mysqli_query($con,$sel_cart);
		$check_cart=mysqli_num_rows($sel_run);
		if($check_customer>0){
		 if($check_cart==0){
			$_SESSION['customer_email']=$c_email;
			echo "<script>alert('you have logged in successfully ,   thank you!')</script>";
			echo "<script>window.open('customers/my_account.php','_self')</script>";
		}
		else{
			$_SESSION['customer_email']=$c_email;
			echo "<script>alert('logged in successfully , thank you!')</script>";
			echo "<script>window.open('checkout.php','_self')</script>";
		}
	}
	}

	?>
</div>