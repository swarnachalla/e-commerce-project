<form action="" method="post">

<table width="600" align="center" bgcolor="wheat" border="5">
<tr align="center">
	<td colspan="2" bgcolor="darkgoldenrod" style="font-size: 18px;">Change password</td>
</tr>
<tr>
	<td align="right">current password</td>
	<td><input type="password" name="current_pass" required></td>
</tr>
<tr>
	<td align="right">New password </td>
	<td><input type="password" name="new_pass" required></td>
</tr>
<tr>
	<td align="right">New password again</td>
	<td><input type="password" name="new_pass_again" required></td>
</tr>
<tr align="center">
<td colspan="2"><input type="submit" name="change_pass" value="change password"></td>
</tr>
</form>
<?php 
include("includes/connect.php");
if(isset($_POST['change_pass'])){
	$current_pass=$_POST['current_pass'];
	$new_pass=$_POST['new_pass'];
	$new_pass_again=$_POST['new_pass_again'];
	$user=$_SESSION['customer_email'];
	$sel_pass="select * from customers where customer_email='$user' AND customer_password='$current_pass'";
	$run_pass=mysqli_query($con,$sel_pass);
	$collect=mysqli_num_rows($run_pass);
	if($collect==0){
		echo "<script>alert('current password is wrong bro')</script>";
		
	}
	if($new_pass!=$new_pass_again){
		echo "<script>alert('new password does not match')</script>";
			
	}
	else{
		$update_pass="update customers set customer_password='$new_pass' where customer_email='$user'";
		$run_update=mysqli_query($con,$update_pass);
		echo "<script>alert('your password has been updated successfully')</script>";
			echo "<script>window.open('my_account.php','_self')</script>";
	}
}

?>