<form action="" method="post">

<table width="700" align="center" bgcolor="wheat" border="5">
<tr align="center">
	<td colspan="2" bgcolor="darkgoldenrod" style="font-size: 16px;">Do you really want to delete your account</td>
</tr>
<tr>
	<td align="center"><input type="submit" name="yes" value="yes"></td>
	<td align="center"><input type="submit" name="no" value="cancel"></td>
</table>
</form>
<?php
include("includes/connect.php");
$user=$_SESSION['customer_email'];
if(isset($_POST['yes'])){
	$del_acc="delete from customers where customer_email='$user'";
	$run_del=mysqli_query($con,$del_acc);
	echo "<script>alert('your account has been deleted')</script>";
			echo "<script>window.open('../index.php','_self')</script>";
}
if(isset($_POST['no'])){
	echo "<script>alert('deletion is cancelled')</script>";
			echo "<script>window.open('my_account.php','_self')</script>";
}
?>