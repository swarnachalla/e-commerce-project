<?php 

          $user=$_SESSION['customer_email'];
          $get_customer="select * from customers where customer_email='$user'";
          $run_customer=mysqli_query($con,$get_customer);
          $row_cus=mysqli_fetch_array($run_customer);
          $c_id=$row_cus['customer_id'];
          $name=$row_cus['customer_name'];
          $email=$row_cus['customer_email'];
          $pass=$row_cus['customer_password'];
          $country=$row_cus['customer_country'];
          $city=$row_cus['customer_city'];
          $contact=$row_cus['customer_contact'];
          $image=$row_cus['customer_image'];
          $address=$row_cus['customer_address'];
         
 ?>
<form action="my_account.php?edit_account=<?php echo $c_id;?>" method="post" enctype="multipart/form-data" >
<table width="650" align="center" bgcolor="wheat" border="5">
<tr align="center">
	<td colspan="2" bgcolor="darkgoldenrod" style="font-size: 18px;">Update your account</td>
</tr>
<tr>
	<td align="right">customer name </td>
	<td><input type="text" name="c_name" value="<?php echo $name;?>"></td>
</tr>
<tr>
	<td align="right">customer email </td>
	<td><input type="text" name="c_email" value="<?php echo $email;?>"></td>
</tr>
<tr>
	<td align="right">customer password </td>
	<td><input type="password" name="c_pass" value="<?php echo $pass;?>"></td>
</tr>
<tr>
	<td align="right">customer country </td>
	<td><select name="c_country" disabled>
	    <option><?php echo $country;?></option
		<option>Afghanisthan</option>
		<option>America</option>
		<option>Australia</option>
		<option>Brazil</option>
		<option>Burma</option>
		<option>Chile</option>
		<option>Denmark</option>
		<option>England</option>
		<option>France</option>
		<option>Holland</option>
		<option>India</option>
		<option>Italy</option>
		<option>Makka</option>
		<option>New york</option>
	</select></td>
</tr>
<tr>
	<td align="right">customer contact </td>
	<td><input type="text" name="c_contact" value="<?php echo $contact;?>"></td>
</tr>
<tr>
	<td align="right">customer city </td>
	<td><input type="text" name="c_city" value="<?php echo $city;?>"></td>
</tr>

<tr>
	<td align="right">customer image </td>
	<td><input type="file" name="c_image"><img src="customer images/<?php echo $image;?>" width="100" height="100"></td>
</tr>
<tr>
	<td align="right">customer address </td>
	<td><textarea name="c_address" rows="20" cols="30"> <?php echo $address;?></textarea></td>
</tr> 
<tr align="center">
<td colspan="2"><input type="submit" name="update" value="update account"></td>
</tr>
</table>
	
</form>

<?php
if(isset($_POST['update'])){
	$ip=getip();
	$customer_id=$_GET['edit_account'];
	$c_name=$_POST['c_name'];
	$c_email=$_POST['c_email'];
	$c_pass=$_POST['c_pass'];
	
	$c_contact=$_POST['c_contact'];
	$c_city=$_POST['c_city'];
	$c_image=$_FILES['c_image']['name'];
	$image_tmp=$_FILES['c_image']['tmp_name'];
	$c_address=$_POST['c_address'];

		move_uploaded_file($image_tmp, "customer images/$c_image");
	      $update_query="update customers set customer_name='$c_name',customer_email='$c_email',customer_password='$c_pass',customer_contact='$c_contact',customer_city='$c_city',customer_image='$c_image',customer_address='$c_address' where customer_id='$customer_id'";
	      $update_run=mysqli_query($con,$update_query);
		if($update_run){
			echo '<center><h1 >you have been updated successfully</h1></center>';
			echo "<script>window.open('my_account.php','_self')</script>";
		}
		else{
			echo '<center><h1 >not updated $update_query</h1></center>';
		}

}
?>
	
