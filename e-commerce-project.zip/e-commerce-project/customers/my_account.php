<?php 
session_start();
include('functions/functions.php');

?>
<html>
<head>
<title>EKart</title>
<link rel="stylesheet" href="styles/style.css" media="all">
</head>
<body>
<!--body wrapper starts here-->
<div class="body_wrapper">
<!--header starts here-->
<div id="header">
	<img id="logo" src="images/admin.png" alt="admin image" height="150" width="200">
	<b>Welcome to EKart</b>
	<img id="banner" src="images/banner.jpg" alt="banner image" height="150" width="500">
</div>
<!--header ends here-->
<!--navbar starts here-->
<div id="navbar">
	<ul id="nav">
	<li><a href="../index.php">Home</a></li>
	<li><a href="../all_products.php">All Products</a></li>
	<li><a href="my_account.php">My Account</a></li>
	<li><a href="../register.php">Sign Up</a></li>
	<li><a href="../cart.php">Shopping Cart</a></li>
	<li><a href="index.php">Contact Us</a></li>
	</ul>
	<!--form starts here-->
<div id="form">
<form  action="../results.php" method="get" enctype="multipart/form-data">
<input type="text" name="searchtext" placeholder="search Products here" >
<input type="submit" name="search" value="search">
	
</form>
</div>
<!--form ends here-->
</div>
<!--navbar ends here-->
<!--content wrapper starts here-->
<div class="content_wrapper">
<!--sidebar starts here-->
<div id="sidebar">
	<div id="side_title">My Account</div>
	
	   <ul id="cats">
	   <?php 
          $user=$_SESSION['customer_email'];
          $get_img="select * from customers where customer_email='$user'";
          $run_img=mysqli_query($con,$get_img);
          $row_img=mysqli_fetch_array($run_img);
          $c_image=$row_img['customer_image'];
          $c_name=$row_img['customer_name'];
          echo "<img src='customer images/$c_image' width='150' height='150' style='align:center;'>";
          
	   ?>
	     <li><a href="my_account.php?my_orders">my orders</li>
	      <li><a href="my_account.php?edit_account">edit account</li>
	       <li><a href="my_account.php?change_pass">change password</li>
	        <li><a href="my_account.php?delete_account">delete account</li>
	        <li><a href="logout.php">logout</li>


	   
	   </ul>


	
	
	
</div>
<!--sidebar ends here-->
<!--content  starts here-->
<div id="content">
<?php cart(); ?>
<div id="cart">
	<span style="float: right; font-size: 15px; line-height: 40px;margin-right: 5px;">
<?php 
   if(isset($_SESSION['customer_email'])){
    echo "<b>Welcome :</b>".$_SESSION['customer_email'];

   }
   else{
   	echo "<b>Welcome Guest</b>";
   }

        if(!isset($_SESSION['customer_email'])){
      echo "<a style='color: yellow'  href='../checkout.php'>Login</a>";
}
else{
	echo "<a style='color: yellow' href='logout.php'>Logout</a>";
}
	?>
	</span>
	

</div>


	<div id="all_pro">

	
	<?php

      if(!isset($_GET['my_orders'])){
      	if(!isset($_GET['edit_account'])){
      		if(!isset($_GET['change_pass'])){
      			if(!isset($_GET['delete_account'])){

      echo "<h2 style='padding: 20px;'>Welcome $c_name</h2>";
	echo "<b>you can see your orders progress by clicking this<a href='my_account.php?my_orders'>  link</b>";
}
}
}
}
	  
      if(isset($_GET['edit_account'])){
      	include("edit_account.php");
      }
     
       if(isset($_GET['change_pass'])){
      	include("change_pass.php");
      }
      if(isset($_GET['delete_account'])){
      	include("delete.php");
      }
   ?>
	
	</div>
</div>
<!--content ends here-->

</div>
<!--content wrapper ends here-->

<div id="footer" align="center">
	<h1>&copy; 2017 by www.ifirst.com</h1>
</div>
</div>
<!--body wrapper endss here-->
</body>
</html>