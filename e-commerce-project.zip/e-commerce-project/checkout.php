<?php 
session_start();
include('functions/functions.php');

?>
<html>
<head>
<title>EKart</title>
<link rel="stylesheet" href="styles/styles.css" media="all">
</head>
<body>
<!--body wrapper starts here-->
<div class="body_wrapper">
<!--header starts here-->
<div id="header">
	<img id="logo" src="images/admin.png" alt="admin image" height="150" width="200">
	<b>Welcome to EKart</b>
	<img id="banner" src="images/banner.jpg" alt="banner image" height="150" width="500">
</div>
<!--header ends here-->
<!--navbar starts here-->
<div id="navbar">
	<ul id="nav">
	<li><a href="index.php">Home</a></li>
	<li><a href="all_products.php">All Products</a></li>
	<li><a href="customers/my_account.php">My Account</a></li>
	<li><a href="index.php">Sign Up</a></li>
	<li><a href="index.php">Shopping Cart</a></li>
	<li><a href="index.php">Contact Us</a></li>
	</ul>
	<!--form starts here-->
<div id="form">
<form  action="results.php" method="get" enctype="multipart/form-data">
<input type="text" name="searchtext" placeholder="search Products here" >
<input type="submit" name="search" value="search">
	
</form>
</div>
<!--form ends here-->
</div>
<!--navbar ends here-->
<!--content wrapper starts here-->
<div class="content_wrapper">
<!--sidebar starts here-->
<div id="sidebar">
	<div id="side_title">Categories</div>
	
	   <ul id="cats">
	   
	   <?php  echo getcat(); ?>
	   </ul>


	<div id="side_title">Brands</div>
	
	   <ul id="cats">

	   <?php  echo getbrand(); ?>

	   </ul>   
	
	
</div>
<!--sidebar ends here-->
<!--content  starts here-->
<div id="content">
<?php cart(); ?>
<div id="cart">
	<span style="float: right; font-size: 15px; line-height: 40px;margin-right: 5px;">
<?php 
   if(isset($_SESSION['customer_email'])){
    echo "<b>Welcome :</b>".$_SESSION['customer_email']."<b style='color: red;'>  your</b>";

   }
   else{
   	echo "<b>Welcome Guest</b>";
   }
?>

	 <b style="color: red">shoping cart-</b>Total items-<?php total_items(); ?> Total price-$ <?php total_price(); ?> <a style="color: red" href="cart.php">Go to cart</a>
	<?php 
        if(!isset($_SESSION['customer_email'])){
      echo "<a style='color: yellow'  href='checkout.php'>Login</a>";
}
else{
	echo "<a style='color: yellow' href='logout.php'>Logout</a>";
}
	?>
	</span>
	</span>
</div>


	<div id="all_pro">

	<?php 
	if(!isset($_SESSION['customer_email'])){
		include('customer_login.php');
	}
	else{
		include('payment.php');
	}
	?>
	</div>
</div>
<!--content ends here-->

</div>
<!--content wrapper ends here-->

<div id="footer" align="center">
	<h1>&copy; 2017 by www.ifirst.com</h1>
</div>
</div>
<!--body wrapper endss here-->
</body>
</html>