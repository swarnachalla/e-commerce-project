<?php 
session_start();
include('functions/functions.php');
include('includes/connect.php');

?>
<html>
<head>
<title>EKart| Register</title>
<link rel="stylesheet" href="styles/styles.css" media="all">
</head>
<body>
<!--body wrapper starts here-->
<div class="body_wrapper">
<!--header starts here-->
<div id="header">
	<img id="logo" src="images/admin.png" alt="admin image" height="150" width="200">
	<b>Welcome to EKart</b>
	<img id="banner" src="images/banner.jpg" alt="banner image" height="150" width="500">
</div>
<!--header ends here-->
<!--navbar starts here-->
<div id="navbar">
	<ul id="nav">
	<li><a href="index.php">Home</a></li>
	<li><a href="all_products.php">All Products</a></li>
	<li><a href="customers/my_account.php">My Account</a></li>
	<li><a href="register.php">Sign Up</a></li>
	<li><a href="cart.php">Shopping Cart</a></li>
	<li><a href="index.php">Contact Us</a></li>
	</ul>
	<!--form starts here-->
<div id="form">
<form  action="results.php" method="get" enctype="multipart/form-data">
<input type="text" name="searchtext" placeholder="search Products here" >
<input type="submit" name="search" value="search">
	
</form>
</div>
<!--form ends here-->
</div>
<!--navbar ends here-->
<!--content wrapper starts here-->
<div class="content_wrapper">
<!--sidebar starts here-->
<div id="sidebar">
	<div id="side_title">Categories</div>
	
	   <ul id="cats">
	   
	   <?php  echo getcat(); ?>
	   </ul>


	<div id="side_title">Brands</div>
	
	   <ul id="cats">

	   <?php  echo getbrand(); ?>

	   </ul>   
	
	
</div>
<!--sidebar ends here-->
<!--content  starts here-->
<div id="content">
<?php cart(); ?>
<div id="cart">
	<span style="float: right; font-size: 18px; line-height: 40px;margin-right: 5px;">welcome user! <b style="color: red">shoping cart-</b>Total items-<?php total_items(); ?> Total price-$ <?php total_price(); ?> <a style="color: red" href="cart.php">Go to cart</a>
	<?php 
        if(!isset($_SESSION['customer_email'])){
      echo "<a style='color: yellow'  href='checkout.php'>Login</a>";
}
else{
	echo "<a style='color: yellow' href='logout.php'>Logout</a>";
}
	?>
	</span>
</div>
<form action="register.php" method="post" enctype="multipart/form-data" >
<table width="750" align="center" bgcolor="wheat" border="5">
<tr align="center">
	<td colspan="2" bgcolor="darkgoldenrod" style="font-size: 18px;">Create an account</td>
</tr>
<tr>
	<td align="right">customer name </td>
	<td><input type="text" name="c_name" required></td>
</tr>
<tr>
	<td align="right">customer email </td>
	<td><input type="text" name="c_email" required></td>
</tr>
<tr>
	<td align="right">customer password </td>
	<td><input type="password" name="c_pass" required></td>
</tr>
<tr>
	<td align="right">customer country </td>
	<td><select name="c_country" required>
	    <option>choose country</option
		<option>Afghanisthan</option>
		<option>America</option>
		<option>Australia</option>
		<option>Brazil</option>
		<option>Burma</option>
		<option>Chile</option>
		<option>Denmark</option>
		<option>England</option>
		<option>France</option>
		<option>Holland</option>
		<option>India</option>
		<option>Italy</option>
		<option>Makka</option>
		<option>New york</option>
	</select></td>
</tr>
<tr>
	<td align="right">customer contact </td>
	<td><input type="text" name="c_contact" required></td>
</tr>
<tr>
	<td align="right">customer city </td>
	<td><input type="text" name="c_city" required></td>
</tr>

<tr>
	<td align="right">customer image </td>
	<td><input type="file" name="c_image" required></td>
</tr>
<tr>
	<td align="right">customer address </td>
	<td><textarea name="c_address" rows="20" cols="30" ></textarea></td>
</tr> 
<tr align="center">
<td colspan="2"><input type="submit" name="register" value="create account"></td>
</tr>
</table>
	
</form>

<?php
if(isset($_POST['register'])){
	$ip=getip();
	$c_name=$_POST['c_name'];
	$c_email=$_POST['c_email'];
	$c_pass=$_POST['c_pass'];
	$c_country=$_POST['c_country'];
	$c_contact=$_POST['c_contact'];
	$c_city=$_POST['c_city'];
	$c_image=$_FILES['c_image']['name'];
	$image_tmp=$_FILES['c_image']['tmp_name'];
	$c_address=$_POST['c_address'];

		move_uploaded_file($image_tmp, "customers/customer images/$c_image");
	      $query="insert into customers (customer_ip,customer_name,customer_email,customer_password,customer_country,customer_city,customer_address,customer_contact,customer_image) values('$ip','$c_name','$c_email','$c_pass','$c_country','$c_city','$c_address','$c_contact','$c_image')";
		if(mysqli_query($con,$query)){
			echo '<center><h1 >you have registered in successfully</h1></center>';
		}
		$sel_cart="select * from cart where ip_add='$ip'";
		$sel_run=mysqli_query($con,$sel_cart);
		$check_cart=mysqli_num_rows($sel_run);
		if($check_cart==0){
			$_SESSION['customer_email']=$c_email;
			echo "<script>alert('account created successfully , thank you!')</script>";
			echo "<script>window.open('customers/my_account.php','_self')</script>";
		}
		else{
			$_SESSION['customer_email']=$c_email;
			echo "<script>alert('account created successfully , thank you!')</script>";
			echo "<script>window.open('checkout.php','_self')</script>";
		}

}
?>
	
</div>
<!--content ends here-->

</div>
<!--content wrapper ends here-->

<div id="footer" align="center">
	<h1>&copy; 2017 by www.ifirst.com</h1>
</div>
</div>
<!--body wrapper endss here-->
</body>
</html>