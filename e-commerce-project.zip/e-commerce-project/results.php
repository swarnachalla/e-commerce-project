<?php 
include('functions/functions.php');

?>
<html>
<head>
<title>EKart</title>
<link rel="stylesheet" href="styles/styles.css" media="all">
</head>
<body>
<!--body wrapper starts here-->
<div class="body_wrapper">
<!--header starts here-->
<div id="header">
	<img id="logo" src="images/admin.png" alt="admin image" height="150" width="200">
	<b>Welcome to EKart</b>
	<img id="banner" src="images/banner.jpg" alt="banner image" height="150" width="500">
</div>
<!--header ends here-->
<!--navbar starts here-->
<div id="navbar">
	<ul id="nav">
	<li><a href="index.php">Home</a></li>
	<li><a href="all_products.php">All Products</a></li>
	<li><a href="customers/my_account.php">My Account</a></li>
	<li><a href="register.php">Sign Up</a></li>
	<li><a href="cart.php">Shopping Cart</a></li>
	<li><a href="index.php">Contact Us</a></li>
	</ul>
	<!--form starts here-->
<div id="form">
<form  action="results.php" method="get" enctype="multipart/form-data">
<input type="text" name="searchtext" placeholder="search Products here" >
<input type="submit" name="search" value="search">
	
</form>
</div>
<!--form ends here-->
</div>
<!--navbar ends here-->
<!--content wrapper starts here-->
<div class="content_wrapper">
<!--sidebar starts here-->
<div id="sidebar">
	<div id="side_title">Categories</div>
	
	   <ul id="cats">
	   
	   <?php  echo getcat(); ?>
	   </ul>


	<div id="side_title">Brands</div>
	
	   <ul id="cats">

	   <?php  echo getbrand(); ?>

	   </ul>   
	
	
</div>
<!--sidebar ends here-->
<!--content  starts here-->
<div id="content">

<div id="cart">
	<span style="float: right; font-size: 15px; line-height: 40px;margin-right: 5px;">
<?php 
   if(isset($_SESSION['customer_email'])){
    echo "<b>Welcome :</b>".$_SESSION['customer_email']."<b style='color: red;'>  your</b>";

   }
   else{
   	echo "<b>Welcome Guest</b>";
   }
?>

	 <b style="color: red">shoping cart-</b>Total items-<?php total_items(); ?> Total price-$ <?php total_price(); ?> <a style="color: red" href="cart.php">Go to cart</a>
	<?php 
        if(!isset($_SESSION['customer_email'])){
      echo "<a style='color: yellow'  href='checkout.php'>Login</a>";
}
else{
	echo "<a style='color: yellow' href='logout.php'>Logout</a>";
}
	?>
	</span>
</div>


	<div id="all_pro">
	<?php
	if(isset($_GET['search'])){
		$search_query=$_GET['searchtext'];
	
	$get_pro="select * from products where product_keywords like '%$search_query%' ";
	$run_pro=mysqli_query($con,$get_pro);
	$count=mysqli_num_rows($run_pro);
	if($count==0){
		echo"<h2>There are no products of this type</h2>";
	}
	while ($row_pro=mysqli_fetch_array($run_pro)) {
		$pro_id=$row_pro['product_id'];
		$pro_title=$row_pro['product_title'];
		$pro_keywords=$row_pro['product_keywords'];
		$pro_price=$row_pro['product_price'];
		$pro_image=$row_pro['product_image'];
		$pro_desc=$row_pro['product_desc'];
		
		echo "
		<div id='single_pro'>
		     <h3>$pro_title</h3>
		     <a href='details.php?pro_id=$pro_id'><img id='pro' src='admin/product_images/$pro_image' alt='image' width='180' height='180'></a>
		     <p><b>price: $ $pro_price</b></p>
		     <a href='details.php?pro_id=$pro_id' style=' float:left;' >details</a>
		     <a href='index.php?add_cart=$pro_id'><button style=' float:right;' >Add to cart</button></a>
		</div>



		";

	}

}
?>

	</div>
</div>
<!--content ends here-->

</div>
<!--content wrapper ends here-->

<div id="footer" align="center">
	<h1>&copy; 2017 by www.ifirst.com</h1>
</div>
</div>
<!--body wrapper endss here-->
</body>
</html>